package com.emard.microservices.productstockenquiryservice.techfxproductenquiryservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechfxProductEnquiryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechfxProductEnquiryServiceApplication.class, args);
	}

}
